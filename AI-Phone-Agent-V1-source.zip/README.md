# AI Phone Agent

A first Android prototype for a OnePlus 8 / Android 13 phone-control assistant.

## V1 prototype
- Accessibility Service
- Open Android Settings
- Global Back / Home
- Basic accessibility-node clicking
- Simple natural-language command parser

The project is intentionally conservative: sensitive or irreversible actions are not automated in V1.
