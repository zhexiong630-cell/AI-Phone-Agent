package com.zhexiong.aiphoneagent;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private TextView status;
    private TextView log;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);
        log = findViewById(R.id.log);
        Button accessibilityButton = findViewById(R.id.accessibilityButton);
        Button runButton = findViewById(R.id.runButton);
        EditText command = findViewById(R.id.command);

        accessibilityButton.setOnClickListener(v -> {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        });

        runButton.setOnClickListener(v -> {
            String text = command.getText().toString().trim();
            if (text.isEmpty()) {
                log.setText("请输入指令。");
                return;
            }
            PhoneControlService.executeNaturalCommand(text);
            log.setText("已发送指令： " + text);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean enabled = PhoneControlService.instance != null;
        status.setText(enabled ? "辅助功能：已启用 ✓" : "辅助功能：未启用");
    }
}
