package com.zhexiong.aiphoneagent;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.provider.Settings;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.Locale;

public class PhoneControlService extends AccessibilityService {
    public static PhoneControlService instance;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(android.view.accessibility.AccessibilityEvent event) { }

    @Override
    public void onInterrupt() { }

    @Override
    public void onDestroy() {
        if (instance == this) instance = null;
        super.onDestroy();
    }

    public static void executeNaturalCommand(String command) {
        if (instance == null) return;

        String c = command.toLowerCase(Locale.ROOT);

        if (c.contains("返回") || c.equals("back")) {
            instance.performGlobalAction(GLOBAL_ACTION_BACK);
            return;
        }

        if (c.contains("主页") || c.contains("home")) {
            instance.performGlobalAction(GLOBAL_ACTION_HOME);
            return;
        }

        if (c.contains("设置") || c.contains("settings")) {
            Intent i = new Intent(Settings.ACTION_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            instance.startActivity(i);
            return;
        }

        // V1 fallback: find a visible node whose text/content description
        // matches a common target and click it.
        AccessibilityNodeInfo root = instance.getRootInActiveWindow();
        if (root != null) {
            String[] targets = {"确定", "下一步", "继续", "搜索", "菜单"};
            for (String target : targets) {
                if (clickFirstMatching(root, target)) return;
            }
        }
    }

    private static boolean clickFirstMatching(AccessibilityNodeInfo node, String target) {
        if (node == null) return false;

        CharSequence text = node.getText();
        CharSequence desc = node.getContentDescription();
        if ((text != null && target.contentEquals(text)) ||
            (desc != null && target.contentEquals(desc))) {
            if (node.isClickable()) {
                return node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            }
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            if (clickFirstMatching(node.getChild(i), target)) return true;
        }
        return false;
    }
}
